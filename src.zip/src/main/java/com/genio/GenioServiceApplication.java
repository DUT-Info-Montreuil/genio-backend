package com.genio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenioServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(GenioServiceApplication.class, args);
    }
}


