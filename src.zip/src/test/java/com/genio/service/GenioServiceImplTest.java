package com.genio.service;

import com.genio.dto.EnseignantDTO;
import com.genio.dto.EtudiantDTO;
import com.genio.dto.TuteurDTO;
import com.genio.exception.business.InvalidDataException;
import com.genio.exception.business.ModelNotFoundException;
import com.genio.repository.*;
import com.genio.dto.request.ConventionServiceDTO;
import com.genio.repository.*;
import com.genio.service.impl.GenioServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GenioServiceImplTest {

    @Mock
    private ModeleRepository modeleRepository;

    @Mock
    private EtudiantRepository etudiantRepository;

    @Mock
    private TuteurRepository tuteurRepository;

    @Mock
    private EnseignantRepository enseignantRepository;

    @Mock
    private HistorisationRepository historisationRepository;

    @Mock
    private ConventionRepository conventionRepository; // Ajouter le mock manquant

    @InjectMocks
    private GenioServiceImpl genioService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Initialise les mocks avant chaque test
    }

    @Test
    void shouldThrowInvalidDataExceptionWhenDataIsInvalid() {
        // Préparer les données d'entrée invalides
        ConventionServiceDTO input = new ConventionServiceDTO();
        input.setModeleId(null); // Données invalides

        // Vérifier que l'exception InvalidDataException est levée
        Exception exception = assertThrows(InvalidDataException.class, () -> {
            genioService.generateConvention(input, "DOCX");
        });

        // Vérifier le message d'erreur
        assertTrue(exception.getMessage().contains("L'ID du modèle est manquant"));
    }

    @Test
    void shouldThrowModelNotFoundExceptionWhenModelIsMissing() {
        // Préparer les données d'entrée valides
        ConventionServiceDTO input = new ConventionServiceDTO();
        input.setModeleId(1L);
        input.setEtudiant(new EtudiantDTO("Nom", "Prenom", "Masculin", "01/01/2000", "Adresse", "0102030405", "email@example.com"));
        input.setTuteur(new TuteurDTO("NomTuteur", "PrenomTuteur", "Directeur", "0102030406", "tuteur@example.com"));
        input.setEnseignant(new EnseignantDTO("NomEns", "PrenomEns", "ens@example.com"));

        // Mock : Modèle non trouvé
        when(modeleRepository.findById(1L)).thenReturn(java.util.Optional.empty());

        // Vérifier que l'exception ModelNotFoundException est levée
        Exception exception = assertThrows(ModelNotFoundException.class, () -> {
            genioService.generateConvention(input, "DOCX");
        });

        // Vérifier le message d'erreur
        assertTrue(exception.getMessage().contains("Modèle non trouvé pour l'ID"));
    }


}