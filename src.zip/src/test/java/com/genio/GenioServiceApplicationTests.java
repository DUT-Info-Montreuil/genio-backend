package com.genio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenioServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
